// bookTypes.ts
export interface Book {
  title: string;
  description: string;
  rating: number;
  read: boolean; // Add this line
}
